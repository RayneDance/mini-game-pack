import pygame
from engine.engine import Engine
from engine.components.render import Render
from engine.components.transform import Transform

ENGINE = Engine(pygame)